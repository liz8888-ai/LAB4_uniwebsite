// Frontend JavaScript: connects the pages to the PHP backend
const API = "../backend";

// If a page is shown inside the home-page iframe, hide its header, menu and footer
if (window.self !== window.top) {
    document.body.classList.add("embedded");
}

// Hide the logo if the image file is missing
document.querySelectorAll(".logo").forEach(img => {
    img.addEventListener("error", () => { img.style.display = "none"; });
});

// ---------- Home page: check the backend ----------
const status = document.getElementById("server-status");

if (status) {
    const line = document.getElementById("status-line");

    fetch(API + "/get_students.php")
        .then(r => { if (!r.ok) throw new Error(); return r.json(); })
        .then(d => {
            status.textContent = "connected (" + d.count + " students saved)";
            line.className = "status ok";
        })
        .catch(() => {
            status.textContent = "not reachable. Start the PHP server (see README).";
            line.className = "status bad";
        });
}

// ---------- Form page: send data to the backend ----------
const form = document.getElementById("studentForm");

if (form) {
    const msg = document.getElementById("msg");

    form.addEventListener("submit", e => {
        e.preventDefault();

        // Browser checks first (required, email format, 0-100)
        if (!form.checkValidity()) {
            form.reportValidity();
            return;
        }

        fetch(API + "/submit.php", { method: "POST", body: new FormData(form) })
            .then(r => r.json())
            .then(d => {
                if (d.success) {
                    msg.className = "success";
                    msg.innerHTML = d.message + ' <a href="table.html">View the results table</a>';
                    form.reset();
                } else {
                    msg.className = "error";
                    msg.innerHTML = "<ul>" + d.errors.map(x => "<li>" + x + "</li>").join("") + "</ul>";
                }
            })
            .catch(() => {
                msg.className = "error";
                msg.textContent = "Could not reach the backend. Start the PHP server (see README).";
            });
    });
}

// ---------- Table page: load data from the backend ----------
const tableBody = document.getElementById("tableBody");

if (tableBody) {
    fetch(API + "/get_students.php")
        .then(r => { if (!r.ok) throw new Error(); return r.json(); })
        .then(d => {
            if (d.students.length === 0) {
                tableBody.innerHTML = '<tr><td colspan="7">No students yet. Use the registration form to add one.</td></tr>';
            } else {
                // Text was already made safe by clean() in PHP (htmlspecialchars)
                tableBody.innerHTML = d.students.map((s, i) => `
                    <tr>
                        <td>${i + 1}</td>
                        <td>${s.enrollment}</td>
                        <td>${s.name}</td>
                        <td>${s.course}</td>
                        <td>${s.gender}</td>
                        <td>${s.marks}</td>
                        <td><span class="grade g-${s.grade.replace("+", "plus")}">${s.grade}</span></td>
                    </tr>`).join("");
            }
            document.getElementById("average").textContent = d.average;
            document.getElementById("count").textContent = d.count;
        })
        .catch(() => {
            tableBody.innerHTML = '<tr><td colspan="7">Could not load data. Start the PHP server (see README).</td></tr>';
        });
}
