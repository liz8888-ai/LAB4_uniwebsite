<?php
// Shared settings and helper functions (used by submit.php and get_students.php)

// Every backend file answers with JSON
if (!headers_sent()) {
    header("Content-Type: application/json; charset=UTF-8");
}

// File where student data is stored
define("DATA_FILE", __DIR__ . "/data/students.json");

// Read all students from the JSON file
function load_students() {
    if (!file_exists(DATA_FILE)) {
        return [];
    }
    $content = file_get_contents(DATA_FILE);
    if ($content === false || trim($content) === "") {
        return [];
    }
    $students = json_decode($content, true);
    return is_array($students) ? $students : [];
}

// Write all students back to the JSON file
function save_students($students) {
    $dir = dirname(DATA_FILE);
    if (!is_dir($dir) && !mkdir($dir, 0775, true)) {
        return false;
    }
    $json = json_encode($students, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    if ($json === false) {
        return false;
    }
    return file_put_contents(DATA_FILE, $json, LOCK_EX) !== false;
}

// Marks -> grade
function grade($marks) {
    if ($marks >= 90) return "A+";
    if ($marks >= 80) return "A";
    if ($marks >= 70) return "B";
    if ($marks >= 60) return "C";
    return "D";
}

// Clean user input: trims spaces and blocks HTML/script injection (XSS)
function clean($value) {
    return htmlspecialchars(trim((string)($value ?? "")), ENT_QUOTES, "UTF-8");
}
