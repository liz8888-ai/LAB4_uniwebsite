<?php
// Receives the registration form, validates it and saves it
require_once __DIR__ . "/config.php";

function fail($code, $errors) {
    http_response_code($code);
    echo json_encode(["success" => false, "errors" => $errors]);
    exit;
}

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    fail(405, ["Only POST requests are allowed."]);
}

// Read values from $_POST and clean them
$name       = clean($_POST["name"] ?? "");
$enrollment = clean($_POST["enrollment"] ?? "");
$email      = clean($_POST["email"] ?? "");
$course     = clean($_POST["course"] ?? "");
$gender     = clean($_POST["gender"] ?? "");
$marks      = trim($_POST["marks"] ?? "");

// ---- Validation ----
$errors = [];

if ($name === "")       $errors[] = "Name is required.";
if ($enrollment === "") $errors[] = "Enrollment number is required.";
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = "Enter a valid email address.";
if (!in_array($course, ["B.Tech CSE", "BCA", "MCA", "B.Sc IT"], true)) $errors[] = "Select a course.";
if (!in_array($gender, ["Male", "Female", "Other"], true))             $errors[] = "Select a gender.";
if (!is_numeric($marks) || $marks < 0 || $marks > 100)                 $errors[] = "Marks must be between 0 and 100.";

$students = load_students();

// Enrollment numbers must be unique
foreach ($students as $s) {
    if (strcasecmp($s["enrollment"], $enrollment) === 0) {
        $errors[] = "Enrollment number $enrollment is already registered.";
        break;
    }
}

if ($errors) {
    fail(400, $errors);
}

// ---- Save ----
$students[] = [
    "enrollment" => $enrollment,
    "name"       => $name,
    "email"      => $email,
    "course"     => $course,
    "gender"     => $gender,
    "marks"      => (int)$marks,
];

if (!save_students($students)) {
    fail(500, ["Could not save the data. Check the backend/data folder."]);
}

echo json_encode(["success" => true, "message" => "Student $name saved successfully!"]);
