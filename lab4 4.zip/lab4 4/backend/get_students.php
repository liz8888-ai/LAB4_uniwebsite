<?php
// Sends all saved students to the table page as JSON
require_once __DIR__ . "/config.php";

$students = load_students();

// Add a grade to every student
foreach ($students as &$student) {
    $student["grade"] = grade($student["marks"]);
}
unset($student);

// Class average
$average = count($students)
    ? round(array_sum(array_column($students, "marks")) / count($students), 1)
    : 0;

echo json_encode([
    "count"    => count($students),
    "average"  => $average,
    "students" => $students,
]);
