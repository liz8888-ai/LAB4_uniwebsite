# Amity University Tashkent - Lab Work 4

3-page website (frame, form, table) with an HTML/CSS/JS frontend and a PHP backend.

## Run it

1. Open a terminal **inside this `lab4` folder** (the one that contains `frontend` and `backend`).
2. Start the PHP server:

       php -S localhost:8000

3. Open http://localhost:8000/frontend/index.html in your browser.
4. Stop the server with Ctrl + C.

Do not open the pages with Live Server (port 5500) or by double-clicking: PHP only runs through a PHP server.

## Folders

- `frontend/` - index.html, about.html, form.html, table.html, css/, js/, images/
- `backend/`  - config.php, submit.php, get_students.php, data/students.json
